#pragma once
#include <iostream>
using namespace std;
string infixToPostfix(string v);
int prec(char v);
int postfixEvaluatin(string v);
