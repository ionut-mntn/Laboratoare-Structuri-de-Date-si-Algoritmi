#include "ThirdPriorityQueue.h"
#include <exception>
#include <iostream>
using namespace std;

ThirdPriorityQueue ::ThirdPriorityQueue(Relation r){
    len = 0;
    cap = 20;
    pozitie_coada = 0;
    Queue = new Element [cap];
    rel = r;
    p1 = p2= make_pair(0,0);

}

void ThirdPriorityQueue ::bubble_up(int pozition){
    int poz = pozition;
    Element elem = Queue[poz];
    int parent = (poz -1)/2;
     while (poz>0 && rel(elem.second, Queue[parent].second))
     {
         Queue[poz] = Queue[parent];
         poz = parent;
         parent = (poz - 1)/2;
     }
     Queue[poz] = elem;
}

void ThirdPriorityQueue :: bubble_down(int pozition){
    int poz = pozition, max_child =-1;
    Element elem = Queue[poz];
    while(poz < pozitie_coada-1)
    {
        max_child = -1;
        if(poz*2+1 <= pozitie_coada -1)
            max_child=poz*2+1;
        if(poz*2 + 2 <=pozitie_coada-1 && rel(Queue[2*poz+2].second,Queue[2*poz+1].second))
            max_child = poz*2+2;
        if(max_child !=-1 && rel(Queue[max_child].second, elem.second))
        {
            Queue[poz] = Queue[max_child];
            poz = max_child;
        }else{
            Queue[poz]=elem;
            poz = pozitie_coada;
        }

    }



}

void ThirdPriorityQueue::push(TElem e, TPriority p) {
    //Element new_elem;
   // new_elem = make_pair(e,p);

    if(len == cap) //resize
    {
        Element* aux;
        cap = cap * 2;
        aux = new Element[cap];

        for(int i=0; i<len;i++)
            aux[i] = Queue [i];

        delete Queue;
        Queue = aux;
        //cout << "Resize";

    }

/*    Queue[len].first = e;
    Queue[len].second = p;
    len ++;
    bubble_up(len-1);*/

    if(len==0) // daca nu mai am elemente
    {
        p1.first =e;
        p1.first = p;
        len ++;

    } else if(len == 1) // daca mai am un element
    {
        if (rel(p1.second, p)) {
            p2.first = e;
            p2.second = p;
            len ++;
        } else {
            p2.first = p1.first;
            p2.second = p1.second;
            p1.first = e;
            p1.first = p;
            len ++;
        }
    }
    else if(len >=2)
    {
        if(rel(p, p1.second))
        {
            Queue[pozitie_coada] = p2;
            p2 = p1;
            p1 = make_pair(e,p);
            len ++;
            pozitie_coada++;
            bubble_up(pozitie_coada-1);
        }
        else if(rel(p1.second, p) && rel(p,p2.second))
        {
            Queue[pozitie_coada] = p2;
            p2 = make_pair(e,p);
            len ++;
            pozitie_coada++;
            bubble_up(pozitie_coada-1);
        } else if(rel(p2.second, p))
        {
            Queue[pozitie_coada] = make_pair(e,p);
            len ++;
            pozitie_coada++;
            bubble_up(pozitie_coada-1);
        }
    }

}

Element ThirdPriorityQueue::top() const {
    if(atMostTwo()) // verific daca am mai putin de 3 elemente
    {
        exception ex;
        throw ex;
    }

   /* if(rel(Queue[0].second,Queue[1].second))
        return Queue[0];
    else if (rel(Queue[1].second, Queue[2].second))
        return Queue[1];
    else
        return Queue[2];*/
    return Queue[0];


}

Element ThirdPriorityQueue::pop() {
    if(atMostTwo()) // verific daca am mai putin de 3 elemente
    {
        exception ex;
        throw ex;
    }
    Element to_delete;
    to_delete = Queue[0];
    Queue[0] = Queue[pozitie_coada-1];
    pozitie_coada --;
    len --;
    bubble_down(0);

    return to_delete;

}

bool ThirdPriorityQueue ::atMostTwo() const {
    if(len <= 2) // verific daca am cel mult 2 elemente
        return true;
    else
        return false;


}

ThirdPriorityQueue ::~ThirdPriorityQueue() { //destructor
    delete Queue; // dealoc spatiul pt Queue

}