#include <iostream>
#include "ThirdPriorityQueue.h"
#include "TestP8.h"

using namespace std;

int main(){
    testP8();
    cout << "Test End"<<endl;
    system("pause");
}